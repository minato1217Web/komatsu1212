<?php get_header(); ?>

<main class="ly_main">
  <div class="md_header">
    <figure class="md_header_mv logo_change_sp">
      <picture>
        <source media="(min-width:769px)" srcset="<?php echo get_theme_file_uri(); ?>/assets/img/news/mv_pc.jpg" width="1600" height="560">
        <img src="<?php echo get_theme_file_uri(); ?>/assets/img/news/mv_sp.jpg" alt="" width="640" height="480">
      </picture>
    </figure>
    <div class="md_header_bg">
      <div class="md_header_inner">
        <h1 class="md_header_title">
          お知らせ
        </h1>
      </div>
      <!-- //md_header_bg -->
    </div>
    <!-- //md_header -->
  </div>

  <ul class="md_breadcrumbs">
    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">HOME</a></li>
    <li>お知らせ</li>
  </ul>

  <div class="pg_news">
    <ul class="pg_news_lists">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
          <li>
            <a class="pg_news_link" href="<?php the_permalink(); ?>">
              <div class="pg_news_header">
                <time class="pg_news_time" datetime="<?php the_time('Y-m-d'); ?>"><?php the_time('Y/m/d'); ?></time>
                <span class="pg_news_icon">NEW</span>
              </div>
              <p class="pg_news_text">
                <?php echo wp_trim_words(get_the_content(), 50, '...'); ?>
              </p>
            </a>
          </li>
        <?php endwhile;
      else : ?>
        <li>記事が見つかりませんでした。</li>
      <?php endif; ?>
    </ul>

    <?php
    $pagination = paginate_links(array(
      'type' => 'array',
      'prev_text' => '&#65308;',
      'next_text' => '&#65310;',
    ));

    if ($pagination) {
      echo '<ul class="page-numbers">';
      foreach ($pagination as $page) {
        echo '<li>' . $page . '</li>';
      }
      echo '</ul>';
    }
    ?>

    <!-- //pg_news -->
  </div>
</main>

<?php get_footer(); ?>
