<?php get_header(); ?>

<main class="ly_main">
  <section class="pg_mv logo_change_sp">
    <div class="pg_mv_detail">
      <figure class="pg_mv_icon">
        <picture>
          <source media="(min-width:769px)" srcset="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_logo_pc.svg" width="297" height="230">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_logo_sp.svg" alt="" width="131" height="105">
        </picture>
      </figure>
      <h2 class="pg_mv_title">
        細やかな手仕事が<br>
        空気をしなやかに<br>
        変えていく
      </h2>
      <p class="pg_mv_text">
        きれいな手順。きれいな加工。きれいな取付。ダクトを通じて社会とつながり、チームプレーで世の中の衛生環境をより良いものに変えていきたい。地上も地下もあらゆる場所がわたしたちのフィールドです。
      </p>
      <!-- //pg_mv_detail -->
    </div>
    <div class="pg_mv_gallery js_mv_gallery">
      <figure class="pg_mv_gallery_img">
        <div class="pg_mv_size3">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_01_01.jpg" alt="" width="1350" height="825">
        </div>
        <div class="pg_mv_size1">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_02_01.jpg" alt="" width="450" height="300">
        </div>
        <div class="pg_mv_size1">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_02_02.jpg" alt="" width="450" height="300">
        </div>
        <div class="pg_mv_size1">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_02_03.jpg" alt="" width="450" height="300">
        </div>
        <div class="pg_mv_size3">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_03_01.jpg" alt="" width="1350" height="825">
        </div>
        <div class="pg_mv_size2">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_04_01.jpg" alt="" width="900" height="600">
        </div>
        <div class="pg_mv_size1">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_04_02.jpg" alt="" width="450" height="600">
        </div>
        <div class="pg_mv_size1">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_05_01.jpg" alt="" width="450" height="300">
        </div>
        <div class="pg_mv_size2">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_05_02.jpg" alt="" width="900" height="300">
        </div>
        <div class="pg_mv_size1">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_06_01.jpg" alt="" width="450" height="600">
        </div>
        <div class="pg_mv_size2">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_06_02.jpg" alt="" width="900" height="600">
        </div>
        <div class="pg_mv_size2">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_07_01.jpg" alt="" width="900" height="300">
        </div>
        <div class="pg_mv_size1">
          <img src="<?php echo get_theme_file_uri(); ?>/assets/img/top/mv_07_02.jpg" alt="" width="450" height="300">
        </div>
      </figure>
      <!-- //pg_mv_gallery -->
    </div>
    <!-- //pg_mv -->
  </section>

  <section class="pg_news">
    <div class="pg_news_inner">
      <h2 class="pg_category_title js_view md_view">
        <span class="pg_category_title_icon">お知らせ</span>
      </h2>
      <ul class="pg_news_lists js_view md_view __fadeUp">

        <?php
        $args = array(
          'post_type' => 'post',
          'posts_per_page' => 6
        );
        $news_query = new WP_Query($args);

        if ($news_query->have_posts()) :
          while ($news_query->have_posts()) : $news_query->the_post(); ?>

            <li>
              <a class="pg_news_link" href="<?php the_permalink(); ?>">
                <div class="pg_news_header">
                  <time class="pg_news_time" datetime="<?php the_time('Y-m-d'); ?>"><?php the_time('Y/m/d'); ?></time>
                  <?php if (get_the_time('U') > strtotime('-7 days')) { ?>
                    <span class="pg_news_icon">NEW</span>
                  <?php } ?>
                </div>
                <p class="pg_news_text">
                  <?php echo wp_trim_words(get_the_content(), 50, '...'); ?>
                </p>
              </a>
            </li>

        <?php endwhile;
          wp_reset_postdata();
        endif;
        ?>

      </ul>
      <ul class="pg_category_btn js_view md_view">
        <li>
          <a class="pg_category_link" href="<?php echo get_permalink(get_option('page_for_posts')); ?>">VIEW MORE</a>
        </li>
      </ul>
      <!-- //pg_news_inner -->
    </div>
    <!-- //pg_news -->
  </section>

  <section class="pg_business">
    <div class="pg_business_inner">
      <h2 class="pg_category_title">
        <span class="pg_category_title_icon">事業内容</span>
      </h2>
      <p class="pg_business_text">
        当社は鉄構造物工事やプラント工事を中心に、小〜大規模まで多岐にわたる種類の工事を行っております。１つ１つオーダーメイドなためお客様のニーズに合わせて製品を作成しております。スピーディーなことはもちろん、安心で確かな製品を作るよう社員一同心がけております。
      </p>
      <!-- //pg_business_inner -->
    </div>
    <div class="pg_business_bg">
      <ul class="pg_business_lists">
        <li class="js_view bgextend bgLRextend">
          <a class="pg_business_link bgappear" href="https://komatsu-ind.jp/business/#steel_structure/">
            <picture class="pg_business_img">
              <source media="(min-width:769px)" srcset="<?php echo get_theme_file_uri(); ?>/assets/img/top/business_img_01_pc.jpg" width="384" height="384">
              <img loading="lazy" src="<?php echo get_theme_file_uri(); ?>/assets/img/top/business_img_01_sp.jpg" alt="" width="560" height="200">
            </picture>
            <p class="pg_business_list_text">鋼構造物工事</p>
          </a>
        </li>
        <li class="js_view bgextend bgLRextend">
          <a class="pg_business_link bgappear" href="https://komatsu-ind.jp/business/#plant/">
            <picture class="pg_business_img">
              <source media="(min-width:769px)" srcset="<?php echo get_theme_file_uri(); ?>/assets/img/top/business_img_02_pc.jpg" width="384" height="384">
              <img loading="lazy" src="<?php echo get_theme_file_uri(); ?>/assets/img/top/business_img_02_sp.jpg" alt="" width="560" height="200">
            </picture>
            <p class="pg_business_list_text">プラント工事</p>
          </a>
        </li>
        <li class="js_view bgextend bgLRextend">
          <a class="pg_business_link bgappear" href="https://komatsu-ind.jp/business/#production/">
            <picture class="pg_business_img">
              <source media="(min-width:769px)" srcset="<?php echo get_theme_file_uri(); ?>/assets/img/top/business_img_03_pc.jpg" width="384" height="384">
              <img loading="lazy" src="<?php echo get_theme_file_uri(); ?>/assets/img/top/business_img_03_sp.jpg" alt="" width="560" height="200">
            </picture>
            <p class="pg_business_list_text">工事設備や生産設備の<br>製作・据付</p>
          </a>
        </li>
        <li class="js_view bgextend bgLRextend">
          <a class="pg_business_link bgappear" href="https://komatsu-ind.jp/business/#maintenance/">
            <picture class="pg_business_img">
              <source media="(min-width:769px)" srcset="<?php echo get_theme_file_uri(); ?>/assets/img/top/business_img_04_pc.jpg" width="384" height="384">
              <img loading="lazy" src="<?php echo get_theme_file_uri(); ?>/assets/img/top/business_img_04_sp.jpg" alt="" width="560" height="200">
            </picture>
            <p class="pg_business_list_text">工場のメンテナンス工事</p>
          </a>
        </li>
      </ul>
      <ul class="pg_category_btn">
        <li>
          <div class="js_view bgextend bgLRextend">
            <span class="bgappear">
              <a class="pg_category_link" href="https://komatsu-ind.jp/business/">VIEW MORE</a>
            </span>
          </div>
        </li>
      </ul>
      <!-- //pg_business_bg -->
    </div>
    <!-- //pg_business -->
  </section>

  <section class="pg_sdgs">
    <div class="pg_sdgs_img">
      <div class="js_view bgextend bgRLextend">
        <figure class="bgappear">
          <img loading="lazy" src="<?php echo get_theme_file_uri(); ?>/assets/img/top/sdgs_img.jpg" alt="" width="864" height="756">
        </figure>
      </div>
    </div>
    <div class="pg_sdgs_box">
      <p class="pg_sdgs_en js_view bgextend bgRLextend">
        <span class="pg_sdgs_en_text bgappear">HOW WE ARE <br>with SDGs</span>
      </p>
      <h2 class="pg_category_title js_view bgextend bgRLextend">
        <span class="pg_category_title_icon bgappear">SDGsへの取り組み</span>
      </h2>
      <p class="pg_sdgs_text js_view bgextend bgRLextend">
        <span class="bgappear">
          当社の事業を通じた SDGsの達成に向けて<strong>「働きやすい職場環境づくり」「環境保全への取り組み」「品質・安全性の向上」「地域社会への貢献」</strong>の取り組みを実施してくことを宣言いたします。
        </span>
      </p>
      <ul class="pg_category_btn">
        <li>
          <div class="js_view bgextend bgRLextend">
            <span class="bgappear">
              <a class="pg_category_link" href="https://komatsu-ind.jp/company/#sdgs/">VIEW MORE</a>
            </span>
          </div>
        </li>
      </ul>
      <!-- pg_sdgs_box -->
    </div>
    <!-- //pg_sdgs -->
  </section>

  <section class="pg_company">
    <div class="pg_company_inner">
      <div class="pg_company_img">
        <div class="js_view bgextend bgLRextend">
          <figure class="bgappear">
            <img loading="lazy" src="<?php echo get_theme_file_uri(); ?>/assets/img/top/icon_logo.jpg" alt="" width="358" height="358">
          </figure>
        </div>
      </div>
      <div class="pg_company_box">
        <h2 class="pg_category_title js_view bgextend bgLRextend">
          <span class="pg_category_title_icon bgappear">会社案内</span>
        </h2>
        <p class="pg_company_text js_view bgextend bgLRextend">
          <span class="bgappear">
            当社は平成3年に設立以来、技術力の向上と人材の育成に努め、社員の幸せと地域社会の発展に貢献して参りました。安全と高品質な製品で地域の発展に貢献すべく、日々の事業を営んでおります。
          </span>
        </p>
        <ul class="pg_category_btn js_view md_view">
          <li>
            <div class="js_view bgextend bgLRextend">
              <span class="bgappear">
                <a class="pg_category_link" href="https://komatsu-ind.jp/company/">VIEW MORE</a>
              </span>
            </div>
          </li>
        </ul>
      </div>
      <!-- pg_company_inner -->
    </div>
    <!-- //pg_company -->
  </section>

</main>
<?php get_footer(); ?>