<?php get_header(); ?>

<main class="ly_main">
  <ul class="md_breadcrumbs __spaceTop_pc">
    <li><a href="<?php echo esc_url(home_url('/')); ?>">HOME</a></li>
    <li><a href="<?php echo esc_url(home_url('/')); ?>news">お知らせ</a></li>
    <li><?php the_title(); ?></li>
  </ul>

  <div class="pg_single">
    <div class="pg_single_main">
      <article class="pg_single_article">
        <div class="pg_single_header">
          <time class="pg_single_time" datetime="<?php the_time('Y-m-d'); ?>"><?php the_time('Y.m.d'); ?></time>
          <span class="pg_single_icon">NEW</span>
          <h1 class="pg_single_title">
            <?php the_title(); ?>
          </h1>
        </div>
        <div class="pg_single_body">
          <?php the_content(); ?>
        </div>
      </article>

      <!-- ページネーション -->
      <?php
      $prev_post = get_previous_post();
      $next_post = get_next_post();

      echo '<ul class="pg_single_pager">';

      if ($prev_post) {
        $prev_url = get_permalink($prev_post->ID);
        echo '<li><a class="pg_single_link __back" href="' . esc_url($prev_url) . '">BACK</a></li>';
      } else {
        echo '<li><span class="pg_single_link __back">BACK</span></li>'; // Or you can hide it completely
      }

      if ($next_post) {
        $next_url = get_permalink($next_post->ID);
        echo '<li><a class="pg_single_link __next" href="' . esc_url($next_url) . '">NEXT</a></li>';
      } else {
        echo '<li><span class="pg_single_link __next">NEXT</span></li>'; // Or you can hide it completely
      }

      echo '</ul>';
      ?>

    </div>

    <aside class="pg_single_aside">
      <h2 class="pg_single_aside_title">
        最新記事
      </h2>
      <ul class="pg_single_aside_lists">
        <?php
        $args = array(
          'posts_per_page' => 10, // 最新の10件を取得
          'post__not_in' => array(get_the_ID()), // 現在の投稿を除外
        );
        $recent_posts = new WP_Query($args);
        while ($recent_posts->have_posts()) : $recent_posts->the_post();
        ?>
          <li>
            <a class="pg_single_aside_link" href="<?php the_permalink(); ?>">
              <div class="pg_single_aside_header">
                <time class="pg_single_aside_time" datetime="<?php the_time('Y-m-d'); ?>"><?php the_time('Y.m.d'); ?></time>
                <span class="pg_single_aside_icon">NEW</span>
              </div>
              <p class="pg_single_aside_text">
                <?php the_title(); ?>
              </p>
            </a>
          </li>
        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>
      </ul>
    </aside>
  </div>
</main>

<?php get_footer(); ?>