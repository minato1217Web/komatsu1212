<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>" />
  <meta name="viewport" content="width=device-width">
  <meta name="format-detection" content="telephone=no">

  <!-- Google Tag Manager -->
  <script>
    (function(w, d, s, l, i) {
      w[l] = w[l] || [];
      w[l].push({
        'gtm.start': new Date().getTime(),
        event: 'gtm.js'
      });
      var f = d.getElementsByTagName(s)[0],
        j = d.createElement(s),
        dl = l != 'dataLayer' ? '&l=' + l : '';
      j.async = true;
      j.src =
        'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
      f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-NQ8V52T2');
  </script>
  <!-- End Google Tag Manager -->

  <!-- favicon -->
  <link rel="icon" href="https://komatsu-ind.jp/assets/img/common/favicon.ico">
  <link rel="icon" type="image/png" href="https://komatsu-ind.jp/assets/img/common/android-icon.png" sizes="192x192">
  <link rel="apple-touch-icon" href="https://komatsu-ind.jp/assets/img/common/apple-touch-icon.png" sizes="180x180">


  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>><?php wp_body_open(); ?>
  <!-- Google Tag Manager (noscript) -->
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NQ8V52T2" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
  <!-- End Google Tag Manager (noscript) -->

  <div class="ly_wrapper">
    <header class="ly_header __fixed_sp">
      <div class="header_inner js_header_scroll">
        <h1 class="header_logo">
          <a href="/">
            <picture>
              <source media="(min-width:769px)" srcset="<?php echo get_theme_file_uri(); ?>/assets/img/common/logo.svg" width="268" height="40">
              <img class="js_logo_change_sp" src="<?php echo get_theme_file_uri(); ?>/assets/img/common/logo_sp_white.svg" alt="有限会社 小松工業" width="170" height="26">
            </picture>
          </a>
        </h1>

        <button id="js_humberger" class="humberger" type="button" aria-controls="navigation" aria-expanded="false" aria-label="メニューの開閉">
          <span class="humberger_inner">
            <span class="humberger_line"></span>
          </span>
        </button>

        <div id="navigation" class="header_nav_area js_nav_area" aria-label="メニュー">
          <nav id="js_glNav" class="glNav">
            <p class="header_nav_logo sp_only">
              <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo get_theme_file_uri(); ?>/assets/img/common/logo_sp_white.svg" alt="有限会社 小松工業" width="170" height="26">
              </a>
            </p>
            <div class="glNav_inner">
              <ul class="glNav_list">
                <li>
                  <a class="glNav_link __home <?php if (is_front_page()) echo 'is_current'; ?>" href="<?php echo esc_url(home_url('/')); ?>">
                    HOME
                  </a>
                </li>
                <li>
                  <a class="glNav_link __news <?php if (is_home() || is_single()) echo 'is_current'; ?>" href="<?php echo esc_url(home_url('/')); ?>news">
                    お知らせ
                  </a>
                </li>
                <li>
                  <a class="glNav_link __business" href="https://komatsu-ind.jp/business/">
                    事業案内
                  </a>
                </li>
                <li>
                  <a class="glNav_link __company" href="https://komatsu-ind.jp/company/">
                    会社案内
                  </a>
                </li>
                <li>
                  <button class="glNav_link glNav_accordionBtn js_sp_accordion_trigger" type="button" aria-expanded="false" aria-controls="glNav_accordion1">
                    採用情報
                  </button>
                  <div id="glNav_accordion1" class="glNav_accordion js_sp_accordion">
                    <ul class="glNav_links_nest">
                      <li>
                        <a class="glNav_link_nest __category" href="https://komatsu-ind.jp/recruit/">
                          採用情報TOP
                        </a>
                      </li>
                      <li>
                        <a class="glNav_link_nest" href="https://komatsu-ind.jp/recruit/welfare/">
                          福利厚生
                        </a>
                      </li>
                      <li>
                        <a class="glNav_link_nest" href="https://komatsu-ind.jp/recruit/interview/">
                          社員インタビュー
                        </a>
                      </li>
                      <li>
                        <a class="glNav_link_nest" href="https://komatsu-ind.jp/recruit/requirements/">
                          募集要項
                        </a>
                      </li>
                    </ul>
                  </div>
                </li>
                <li class="sp_only">
                  <a class="glNav_link __contact" href="<?php echo esc_url(home_url('/')); ?>contact">
                    お問い合わせ
                  </a>
                </li>
                <li class="sp_only">
                  <a class="glNav_link __privacy" href="https://komatsu-ind.jp/privacy/">
                    プライバシーポリシー
                  </a>
                </li>
              </ul>

              <div class="header_column_pc">
                <ul class="header_link_lists">
                  <li>
                    <a class="header_link_tel" href="tel:0299820712">
                      <div class="header_link_tel_inner">
                        <span class="header_link_tel_text">0299-82-0712</span><br>
                        <span class="header_link_tel_text_s">9:00〜18:00（日・祝除く）</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a class="header_link_contact" href="<?php echo esc_url(home_url('/')); ?>contact">
                      <span class="header_link_contact_text">お問い合わせ</span>
                    </a>
                  </li>
                </ul>
                <!-- //header_column_pc -->
              </div>
              <!-- //glNav_inner -->
            </div>
          </nav>
          <div id="js_focus_trap" tabindex="0"></div>
          <!-- //header_nav_area -->
        </div>
        <!-- //header_inner -->
      </div>
    </header>