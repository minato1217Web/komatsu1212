<?php
/*
Template Name: お問い合わせ
*/
get_header();
?>

<main class="ly_main">
	<div class="md_header">
		<figure class="md_header_mv logo_change_sp">
			<picture>
				<source media="(min-width:769px)" srcset="<?php echo get_theme_file_uri(); ?>/assets/img/contact/mv_pc.jpg" width="1600" height="560">
				<img src="<?php echo get_theme_file_uri(); ?>/assets/img/contact/mv_sp.jpg" alt="" width="640" height="480">
			</picture>
		</figure>
		<div class="md_header_bg">
			<div class="md_header_inner">
				<h1 class="md_header_title">
					お問い合わせ
				</h1>
				<p class="md_header_discription">
					この度は、小松工業のホームページをご覧いただきありがとうございます。下記フォームでは業務及び採用に関するお問い合わせを承っております。（※印の箇所は必須項目です）
				</p>
			</div>
		<!-- //md_header_bg --></div>
	<!-- //md_header --></div>
	
	<ul class="md_breadcrumbs">
		<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">HOME</a></li>
		<li>お問い合わせ</li>
	</ul>

	<div class="pg_contact">

      <?php echo do_shortcode( '[contact-form-7 id="2b894bf" title="お問い合わせ"]' ); ?>

	<!-- //pg_contact --></div>
  

</main>

<?php get_footer(); ?>
