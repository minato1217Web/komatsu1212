<footer class="ly_footer">
	<aside class="md_recruit">
		<div class="md_recruit_mv">
			<div class="js_view bgextend bgRLextend">
				<div class="bgappear">
					<picture>
						<source media="(min-width:769px)" srcset="<?php echo get_theme_file_uri(); ?>/assets/img/common/recruit_mv_pc.jpg" width="1920" height="880">
						<img src="<?php echo get_theme_file_uri(); ?>/assets/img/common/recruit_mv_sp.jpg" alt="" width="640" height="400">
					</picture>
				</div>
			</div>
		<!-- //md_recruit_mv --></div>

		<div class="md_recruit_inner">
			<p class="md_recruit_intro">
				<span class="js_view bgextend bgRLextend">
					<span class="md_recruit_intro_en bgappear">RECRUIT</span>
				</span>
				<span class="js_view bgextend bgRLextend">
					<span class="md_recruit_intro_text bgappear">
						<img loading="lazy" src="<?php echo get_theme_file_uri(); ?>/assets/img/common/recruit_text.png" alt="共に未来を作ろう。" width="305" height="42">
					</span>
				</span>
			</p>
			<div class="md_recruit_box">
				<h2 class="md_recruit_title">
					<span class="js_view bgextend bgRLextend">
						<span class="bgappear">
							<span class="md_recruit_title_text">採用情報</span>
						</span>
					</span>
				</h2>
				<div class="js_view bgextend bgRLextend">
					<p class="md_recruit_text bgappear">
						地元でしっかり腰を据えて頑張りたい方大歓迎！<br class="pc_br">まじめにしっかりと仕事に取り組んでくれる方であれば、<br class="pc_br">年齢も経験も問いません。<br class="pc_br">働きやすい環境を整え、ご応募をお待ちしています。<br class="pc_br">更なる成長を遂げる当社であなたの力を活かしてみませんか？
					</p>
				</div>
			</div>
			<ul class="md_recruit_lists">
				<li class="js_view bgextend bgRLextend">
					<a class="md_recruit_link bgappear" href="/recruit/welfare/">
						<img class="md_recrut_img" loading="lazy" src="<?php echo get_theme_file_uri(); ?>/assets/img/common/recruit_img_01.jpg" alt="" width="556" height="370">
						<span class="md_recruit_list_text">福利厚生</span>
					</a>
				</li>
				<li class="js_view bgextend bgRLextend">
					<a class="md_recruit_link bgappear" href="/recruit/interview/">
						<img class="md_recrut_img"  loading="lazy" src="<?php echo get_theme_file_uri(); ?>/assets/img/common/recruit_img_02.jpg" alt="" width="556" height="370">
						<span class="md_recruit_list_text">社員インタビュー</span>
					</a>
				</li>
				<li class="js_view bgextend bgRLextend">
					<a class="md_recruit_link bgappear" href="/recruit/requirements/">
						<img class="md_recrut_img"  loading="lazy" src="<?php echo get_theme_file_uri(); ?>/assets/img/common/recruit_img_03.jpg" alt="" width="556" height="370">
						<span class="md_recruit_list_text">募集要項</span>
					</a>
				</li>
			</ul>
		<!-- //md_recruit_inner --></div>
	<!-- //md_recruit --></aside>

	<aside class="md_contact">
		<div class="md_contact_column __01">
			<h2 class="md_contact_title">お問い合わせ</h2>
			<p class="md_contact_text">
				業務・採用のお問い合わせ窓口<br>
				9:00〜18:00（日・祝除く）
			</p>
			<p class="md_contact_address pc_only">
				茨城県鹿嶋市平井2279-4<br>
				㈱ヤマサキ様 鹿島工場内
			</p>
		</div>
		<div class="md_contact_column __02">
			<ul class="md_contact_lists">
				<li>
					<a class="md_contact_link __contact" href="<?php echo esc_url( home_url( '/' ) ); ?>contact">
						お問い合わせフォーム
					</a>
				</li>
				<li>
					<a class="md_contact_link __tel" href="tel:0299820712">
						0299-82-0712
					</a>
				</li>
				<li>
					<span class="md_contact_link __fax">
						0299-82-1415
					</span>
				</li>
			</ul>
			<p class="md_contact_address sp_only">
				茨城県鹿嶋市平井2279-4<br>
				㈱ヤマサキ様 鹿島工場内
			</p>
		</div>
	</aside>

	<div class="footer_bottom">
		<div class="footer_bottom_inner">
			<ul class="footer_list">
				<li>
					<a class="footer_link" href="<?php echo esc_url( home_url( '/' ) ); ?>">
						HOME
					</a>
				</li>
				<li>
					<a class="footer_link" href=href="<?php echo esc_url( home_url( '/' ) ); ?>news">
						お知らせ
					</href=>
				</li>
				<li>
					<a class="footer_link" href="https://komatsu-ind.jp/business/">
						事業案内
					</a>
				</li>
				<li>
					<a class="footer_link" href="https://komatsu-ind.jp/company/">
						会社案内
					</a>
				</li>
				<li>
					<a class="footer_link" href="https://komatsu-ind.jp/recruit/">
						採用情報
					</a>
					<ul class="footer_links_nest">
						<li>
							<a class="footer_link_nest" href="https://komatsu-ind.jp/recruit/welfare/">
								福利厚生
							</a>
						</li>
						<li>
							<a class="footer_link_nest" href="https://komatsu-ind.jp/recruit/interview/">
								社員インタビュー
							</a>
						</li>
						<li>
							<a class="footer_link_nest" href="https://komatsu-ind.jp/recruit/requirements/">
								募集要項
							</a>
						</li>
					</ul>
				</li>
				<li>
					<a class="footer_link" href="<?php echo esc_url( home_url( '/' ) ); ?>contact">
						お問い合わせ
					</a>
				</li>
				<li>
					<a class="footer_link" href="/privacy/">
						プライバシーポリシー
					</a>
				</li>
			</ul>

			<dl class="footer_dl">
				<dt class="footer_dt">
					<img src="<?php echo get_theme_file_uri(); ?>/assets/img/common/logo.svg" alt="有限会社 小松工業" width="268" height="40">
				</dt>
				<dd>茨城県鹿嶋市平井2279-4 ㈱ヤマサキ様 鹿島工場内</dd>
				<dd>TEL0299-82-0712（FAX末尾1415）</dd>
			</dl>
			<p class="footer_copyright">
				<small>© 2023 有限会社小松工業</small>
			</p>
		<!-- //footer_bottom_inner --></div>
	<!-- //footer_bottom --></div>
</footer>

<!-- //ly_wrapper --></div>


<?php wp_footer(); ?>
</body>
</html>