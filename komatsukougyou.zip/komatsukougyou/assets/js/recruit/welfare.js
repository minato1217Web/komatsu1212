//PCサイズ .pg_get_licensed_lists内で高さが2行以上になった場合の対策
document.addEventListener("DOMContentLoaded", function() {
	function adjustListItemHeight() {
		// ウインドウ幅が1280px以上の場合にのみ実行
		if (window.innerWidth >= 1280) {
			let maxHeight = {};
			let lists = document.querySelectorAll('.pg_get_licensed_lists');
			lists.forEach(function(list) {
				let items = list.querySelectorAll('li');

				items.forEach(function(item, index) {
					let currentHeight = item.offsetHeight;

					if (maxHeight[index] === undefined || currentHeight > maxHeight[index]) {
						maxHeight[index] = currentHeight;
					}
				});
			});

			// 計算された最大の高さを各リストアイテムに適用
			lists.forEach(function(list) {
				let items = list.querySelectorAll('li');
				items.forEach(function(item, index) {
					item.style.minHeight = maxHeight[index] + "px";
				});
			});
		} else {
			// ウインドウ幅が1280px未満の場合、min-heightの設定を削除
			let lists = document.querySelectorAll('.pg_get_licensed_lists');
			lists.forEach(function(list) {
				let items = list.querySelectorAll('li');
		
				items.forEach(function(item) {
					item.style.minHeight = '';
				});
			});
		}
	}
	
	// 初回ロード時に実行
	adjustListItemHeight();
	
	// ウインドウサイズが変更された場合にも実行
	window.addEventListener('resize', adjustListItemHeight);
});


//swiper
const swiperSlides = document.getElementsByClassName("swiper-slide");
const breakPoint = 769; // ブレークポイントを設定
let swiper;
let swiperBool;

window.addEventListener(
	"load",
	() => {
		if (breakPoint < window.innerWidth) {
			swiperBool = false;
		} else {
			createSwiper();
			swiperBool = true;
		}
	},
	false
);

window.addEventListener(
	"resize",
	() => {
		if (breakPoint < window.innerWidth && swiperBool) {
			swiper.destroy(false, true);
			swiperBool = false;
		} else if (breakPoint >= window.innerWidth && !swiperBool) {
			createSwiper();
			swiperBool = true;
		}
	},
	false
);

const createSwiper = () => {
	swiper = new Swiper("#js_swiper", {
		loop: true,
		speed: 400, 
		navigation: {
			nextEl: ".pg_swiper_next",
			prevEl: ".pg_swiper_prev",
		},
		// aria-labelの内容を変更
		a11y: {
		  prevSlideMessage: '前のスライドへ',
		  nextSlideMessage: '次のスライドへ',
		  firstSlideMessage: '最初のスライド',
		  lastSlideMessage: '最後のスライド',
		},
	});
};