/*--------------------------------------------------
* Tab
--------------------------------------------------*/
function initTab(elementClass) {
	const elements = document.getElementsByClassName(elementClass);
	
	Array.from(elements).forEach(element => {
		const tabList = element.querySelectorAll('[role="tab"]');
	
		const toggleTab = (event) => {
			const eventTarget = event.currentTarget;
			const targetPanel = eventTarget.getAttribute('aria-controls');
			const activeTab = element.querySelector('[aria-selected="true"]');
			const activeContent = element.querySelector('[aria-hidden="false"]');
			const duration = 600;
			let startTime = null;
	
			activeTab?.setAttribute('aria-selected', 'false');
			eventTarget?.setAttribute('aria-selected', 'true');
			activeContent?.setAttribute('aria-hidden', 'true');
			const focusedElement = element.querySelector(`#${targetPanel || 'untethered'}`);
			focusedElement?.setAttribute('aria-hidden', 'false');
	
			const target = document.getElementById(targetPanel);
			const start = window.pageYOffset;
			const rect = target.getBoundingClientRect();
			const offset = rect.top;
	
			const scroll = (timestamp) => {
				if (!startTime) startTime = timestamp;
				const elapsed = timestamp - startTime;
				const progress = easeInOutQuad(elapsed, start, offset, duration);
	
				window.scrollTo(0, progress);
	
				if (elapsed < duration) {
					requestAnimationFrame(scroll);
				} else {
					// スクロールが終わったらフォーカスを移動
					const focusableElement = focusedElement.querySelector('.pg_faq_open'); // 例：tabpanel内の最初のボタンにフォーカス
					focusableElement?.focus();
				}
			};
	
			requestAnimationFrame(scroll);
			event.preventDefault();
		};
	
		Array.from(tabList).forEach(tab => {
			tab.addEventListener('click', toggleTab);
		});
	});
}
initTab('js_tab');
