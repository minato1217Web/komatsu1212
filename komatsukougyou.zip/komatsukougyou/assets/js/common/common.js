/*--------------------------------------------------
* header fixed
--------------------------------------------------*/
(function () {
	let startPos = 0; // スクロールの開始位置
	let winScrollTop = 0; // 現在のスクロール位置

	// scrollイベントを設定
	window.addEventListener('scroll', function () {
		winScrollTop = window.scrollY;
		const scrollArea = document.querySelector('.js_header_scroll'); // クラス名で要素を取得

		if (!scrollArea) {
			return; // .scrollAreaがページ上に存在しない場合は何もしない
		}

		if (winScrollTop >= startPos) {
			// 下にスクロールされた場合
			if (winScrollTop >= 180) {
				// 下に200pxスクロールされたら隠す
				scrollArea.classList.add('is_hide');
			}
		} else {
			// 上にスクロールされた場合
			if (startPos - winScrollTop >= 3) {
				// 上に10pxスクロールされたら表示する
				scrollArea.classList.remove('is_hide');
			}
		}

		startPos = winScrollTop; // 現在のスクロール位置を開始位置として設定
	});

	// focusイベントを設定
	document.addEventListener('focus', function(event) {
		const scrollArea = document.querySelector('.js_header_scroll');

		if (!scrollArea) {
			return;
		}

		// イベントのターゲットが.scrollArea内にあるかどうかを確認
		if (scrollArea.contains(event.target)) {
			scrollArea.classList.remove('is_hide');
		}
	}, true); // キャプチャフェーズで動作させる
}());


/*--------------------------------------------------
* menu
--------------------------------------------------*/
(function(){
	//ハンバーガーメニュー展開時に背景を固定
	const backgroundFix = (bool) => {
		const scrollingElement = () => {
			const browser = window.navigator.userAgent.toLowerCase();
			if ("scrollingElement" in document) return document.scrollingElement;
			return document.documentElement;
		};
		
		const scrollY = bool
			? scrollingElement().scrollTop
			: parseInt(document.body.style.top || "0");
		
		const fixedStyles = {
			height: "100vh",
			position: "fixed",
			top: `${scrollY * -1}px`,
			left: "0",
			width: "100vw"
		};
		
		Object.keys(fixedStyles).forEach((key) => {
			document.body.style[key] = bool ? fixedStyles[key] : "";
		});
		
		if (!bool) {
			window.scrollTo(0, scrollY * -1);
		}
	};
		
	//変数定義
	const CLASS = "is_active";
	let flg = false;
	let accordionFlg = false;

	let humberger = document.getElementById("js_humberger");
	let focusTrap = document.getElementById("js_focus_trap");
	let menu = document.querySelector(".js_nav_area");
	let accordionTrigger = document.querySelectorAll(".js_sp_accordion_trigger");
	let accordion = document.querySelectorAll(".js_sp_accordion");

	if (!humberger){ return false; } //ハンバーガーメニューが無い場合処理を中断

	// ハンバーガーメニュー
	//開閉制御
	humberger.addEventListener("click", (e) => { //ハンバーガーボタンが選択されたら
		//初回ロード時のアニメーションちらつき防止クラスを削除
		const navLoading = document.querySelector('.is_nav_loading');
		navLoading?.classList.remove('is_nav_loading');

		e.currentTarget.classList.toggle(CLASS);
		menu.classList.toggle(CLASS);
		if (flg) {// flgの状態で制御内容を切り替え
			backgroundFix(false);
			humberger.setAttribute("aria-expanded", "false");
			humberger.focus();
			flg = false;
			document.documentElement.classList.remove('humberger_open');
		} else {
			backgroundFix(true);
			humberger.setAttribute("aria-expanded", "true");
			flg = true;
			document.documentElement.classList.add('humberger_open');
		}
	});
	window.addEventListener("keydown", (event) => { //escキー押下でメニューを閉じられるように
		if (event.key === "Escape" && flg) {  // flgでメニューが開いているかどうかを確認
			humberger.classList.remove(CLASS);
			menu.classList.remove(CLASS);
	
			backgroundFix(false);
			humberger.focus();
			humberger.setAttribute("aria-expanded", "false");
			document.documentElement.classList.remove('humberger_open');
			flg = false;
		}
	});

	//ハンバーガーメニュー内アコーディオン制御
	accordionTrigger.forEach((item) => {
		item.addEventListener("click", (e) => {
			const isExpanded = e.currentTarget.getAttribute("data-accordion-expanded") === "true";
		
			e.currentTarget.classList.toggle(CLASS);
			e.currentTarget.nextElementSibling.classList.toggle(CLASS);
		
			e.currentTarget.setAttribute("data-accordion-expanded", !isExpanded);
			e.currentTarget.setAttribute("aria-expanded", !isExpanded ? "true" : "false");
		});
	});

	//ハンバーガーメニュー内のaタグが#から始まる場合、メニューを閉じる
	const navLinks = document.querySelectorAll(".js_nav_area a");
	navLinks.forEach(link => {
		if (link.getAttribute("href").startsWith("#")) {
			link.addEventListener("click", e => {
				document.documentElement.classList.remove('humberger_open');
				humberger.classList.remove(CLASS);
				menu.classList.remove(CLASS);
				backgroundFix(false);
				humberger.focus();
				humberger.setAttribute("aria-expanded", "false");
				flg = false;
			});
		}
	});
	
	//フォーカストラップ制御
	focusTrap.addEventListener("focus", (e) => {
		humberger.focus();
	});

})();


/*--------------------------------------------------
* メニューにカーソル、フォーカスがあたったらクラスを追加
--------------------------------------------------*/
(function(){
	// .glNav_list内のli要素を全て選択
	const listItems = document.querySelectorAll('.glNav_list > li');

	// イベントを追加する関数
	const addActiveClass = function() {
		this.classList.add('is_nav_active');
	};

	// イベントを削除する関数
	const removeActiveClass = function(e) {
		const relatedTarget = e.relatedTarget;
		// relatedTargetがこのli要素か、このli要素の子要素であるかどうかをチェック
		if (this === relatedTarget || this.contains(relatedTarget)) {
			return;
		}
		
		// ドロップダウン（.glNav_accordion）が開かれているかどうかをチェック
		const accordionOpened = this.querySelector('.glNav_accordion.is_active');
		if (!accordionOpened) {
				// ドロップダウンが開かれていない場合のみ、is_nav_activeを削除
				this.classList.remove('is_nav_active');
		}
	};

	// 各li要素に対してイベントリスナーを追加
	listItems.forEach((item) => {
		// カーソルが当たった場合
		item.addEventListener('mouseover', addActiveClass);

		// カーソルが外れた場合
		item.addEventListener('mouseout', removeActiveClass);

		// フォーカスが当たった場合
		item.addEventListener('focusin', addActiveClass);

		// フォーカスが外れた場合
		item.addEventListener('focusout', removeActiveClass);
	});
})();


/*--------------------------------------------------
* easing
--------------------------------------------------*/
// イージング関数（easeInOutQuad）の定義
const easeInOutQuad = (t, b, c, d) => {
	t /= d / 2;
	if (t < 1) return (c / 2) * t * t + b;
	t--;
	return (-c / 2) * (t * (t - 2) - 1) + b;
};


/*--------------------------------------------------
* smooth scroll
--------------------------------------------------*/
// スムーズスクロール関数の定義
const smoothScroll = (target, duration) => {
	const offset = 0;  // スクロール位置の余白の設定
	const targetPosition = target ? target.offsetTop - offset : 0;
	const startPosition = window.pageYOffset;
	const distance = targetPosition - startPosition;
	let startTime = null;
	
	const animation = (currentTime) => {
		if (!startTime) startTime = currentTime;
		const timeElapsed = currentTime - startTime;
		const ease = easeInOutQuad(timeElapsed, startPosition, distance, duration);
		window.scrollTo(0, ease);
		if (timeElapsed < duration) requestAnimationFrame(animation);
	};
	
	requestAnimationFrame(animation);
};
	
// ページが読み込まれたらスムーズスクロールを実行する
window.addEventListener("DOMContentLoaded", () => {
	const targetHash = window.location.hash; // 現在のハッシュを保存
	
	if (targetHash) {
		// デフォルトのスクロール動作をキャンセル
		history.replaceState("", document.title, window.location.pathname + window.location.search);
	
		// ページの全ての要素がロードされた後にスムーズスクロールを実行
		window.addEventListener("load", () => {
			setTimeout(() => {
				const target = document.querySelector(targetHash);
				if (target) {
				smoothScroll(target, 800);
				}
			}, 0);
		});
	}
});


/*--------------------------------------------------
* scroll view animation
--------------------------------------------------*/
document.addEventListener("DOMContentLoaded", function () {
	const mdViews = document.querySelectorAll(".js_view");

	const observer = new IntersectionObserver((entries) => {
		entries.forEach(entry => {
			if (entry.isIntersecting) {
				entry.target.classList.add("is_view");
				observer.unobserve(entry.target);
			}
		});
	}, {
		rootMargin: "0% 0% -18% 0%"
	});

	mdViews.forEach(mdView => {
		observer.observe(mdView);
	});
});


/*--------------------------------------------------
* Accordion animation
--------------------------------------------------*/
document.addEventListener('DOMContentLoaded', () => {
	const details = document.querySelectorAll('.js_accordion');
	if (!details.length) return;
	details.forEach(element => {
		const summary = element.querySelector('summary');
		const content = element.querySelector('summary + div');
		if (!summary || !content) return;
		summary.addEventListener('click', e => {
			e.preventDefault();
			if (element.open) {
				const openDetails = content.animate({
					height: [content.offsetHeight + 'px', 0],
				}, {
					duration: 250,
					easing: 'ease-out',
				});
				openDetails.onfinish = () => {
					element.removeAttribute('open');
					element.classList.remove('is_open');
				}
			} else {
				element.setAttribute('open', 'true');
				const openDetails = content.animate({
					height: [0, content.offsetHeight + 'px'],
				}, {
					duration: 250,
					easing: 'ease-out',
				});
				openDetails.onfinish = () => {
					element.classList.add('is_open');
				}
			}
		});
	});
});


/* =========================================
SPサイズ メインビュー内のロゴカラーを変更
========================================= */
const options = {
	root: null, // ビューポートをルートとする
	rootMargin: '-50px', // マージンなし
	threshold: 0 // 交差した瞬間にcallbackを呼び出す
};

// callback関数定義
function handleIntersect(entries, observer) {
	entries.forEach(entry => {
		// .pg_mvの下部がビューポートから出たかどうかを判定
		if (!entry.isIntersecting) {
			// src属性を変更
			document.querySelector('.js_logo_change_sp').setAttribute('src', '/assets/img/common/logo_sp.svg');
		} else {
			// src属性を元に戻す
			document.querySelector('.js_logo_change_sp').setAttribute('src', '/assets/img/common/logo_sp_white.svg');
		}
	});
}

// IntersectionObserverを作成
const observer = new IntersectionObserver(handleIntersect, options);

// .logo_change_sp要素を監視対象にする
const targetElement = document.querySelector('.logo_change_sp');

// targetElementが存在する場合のみ、observeを行う
if (targetElement) {
	observer.observe(targetElement);
}


/*--------------------------------------------------
* init / other
--------------------------------------------------*/
//iOS設定
const ua = navigator.userAgent.toLowerCase();
const isiOS = (ua.indexOf('iphone') > -1) || (ua.indexOf('ipad') > -1);
if(isiOS) {
	//iOS フォーム入力 ズームの防止
	let viewport = document.querySelector('meta[name="viewport"]');
	if(viewport) {
		let viewportContent = viewport.getAttribute('content');
		viewport.setAttribute('content', viewportContent + ', user-scalable=no');
	}
}

//スクロールバーの幅を取得
function getScrollbarWidth() {
	let scrollbarWidth = window.innerWidth - document.body.clientWidth;
	document.documentElement.style.setProperty('--scrollbarWidth', scrollbarWidth + 'px');
}
getScrollbarWidth();

//micromoal.js
MicroModal.init({
	openClass: 'is_open',
	disableScroll: false,
	disableFocus: false,
	awaitOpenAnimation: true,
	awaitCloseAnimation: true,
	onShow: modal => {
		getScrollbarWidth();
		document.querySelector('body').classList.add('modal_open');

		// フォーカスをモーダル内に制限するための処理
		const focusableEls = modal.querySelectorAll('a, button, input, textarea, select, details, [tabindex]:not([tabindex="-1"])');
		const firstFocusableEl = focusableEls[0];
		const lastFocusableEl = focusableEls[focusableEls.length - 1];
		
		const trapFocus = event => {
			if (event.key === 'Tab' || event.keyCode === 9) {
				if (event.shiftKey) /* shift + tab */ {
					if (document.activeElement === firstFocusableEl) {
						lastFocusableEl.focus();
						event.preventDefault();
					}
				} else /* tab */ {
					if (document.activeElement === lastFocusableEl) {
						firstFocusableEl.focus();
						event.preventDefault();
					}
				}
			}
		};

		// md_modal_contents 内でのクリックイベントの伝播を止める
		const modalContents = modal.querySelector('.md_modal_contents');
			if (modalContents) {
				modalContents.addEventListener('click', function(event) {
				event.stopPropagation();
			});
		}
		
		modal.addEventListener('keydown', trapFocus);
	},
	onClose: modal => {
		document.querySelector('body').classList.remove('modal_open');
	},
});
