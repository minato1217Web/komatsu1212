<?php
  function my_setup(){
    add_theme_support('post-thumbnails'); // アイキャッチ画像を有効化
    add_theme_support('automatic-feed-links'); // 投稿とコメントのRSSフィードのリンクを有効化
    add_theme_support('title-tag'); // titleタグ自動生成
    add_theme_support('html5', array( // HTML5による出力
      'search-form',
      'comment-form',
      'comment-list',
      'gallery',
      'caption',
    ));
  }
  add_action('after_setup_theme', 'my_setup');

  function my_script_init() { 

    // Preconnect links for Google Fonts
    add_action('wp_head', function() {
        echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
        echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
    });

    // Google Fonts
    wp_enqueue_style('NotoSans', '//fonts.googleapis.com/css2?family=Bebas+Neue&family=Noto+Sans+JP:wght@400;500;700&display=swap');

    // 共通設定読み込み
    wp_enqueue_script('plugins-js', get_template_directory_uri() . '/assets/js/common/plugins.js', array(), '1.0.1', true );
    wp_enqueue_script('common-js', get_template_directory_uri() . '/assets/js/common/common.js', array(), '1.0.1', true );
    wp_enqueue_script('contact-js', get_template_directory_uri() . '/assets/js/contact.js', array(), '1.0.1', true );
    wp_enqueue_style('reset-css', get_template_directory_uri() . '/assets/css/common/reset.css', array(), '1.0.1' );
    wp_enqueue_style('common-css', get_template_directory_uri() . '/assets/css/common/common.css', array(), '1.0.1' );

     //topページのみ下記を読み込み
    if ( is_front_page() ) {
      wp_enqueue_style( 'top-css', get_template_directory_uri() . '/assets/css/pages/top.css', array(), '1.0.1' );
      wp_enqueue_script( 'top-js', get_template_directory_uri() . '/assets/js/top.js', array(), '1.0.1', true );
    }

    //固定ページスラッグcontactのみ下記を読み込み
    if (is_page('contact')) {
      wp_enqueue_style('contact-css', get_template_directory_uri().'/assets/css/pages/contact.css');
      wp_enqueue_style('form_contactform_extension-css', get_template_directory_uri().'/assets/css/common/form_contactform_extension.css');
      wp_enqueue_style('form-css', get_template_directory_uri().'/assets/css/common/form.css');
    }

    //home.php&single.phpのみ下記読み込み
    if (is_home() || is_single()) {
      wp_enqueue_style('news-css', get_template_directory_uri().'/assets/css/pages/news.css');
    }  
  }
  add_action('wp_enqueue_scripts', 'my_script_init');

  //記事表示時の整形無効
  remove_filter('the_content', 'wpautop');
  remove_filter('the_excerpt', 'wpautop');

  // ビジュアルエディタ(TinyMCE)の整形無効
  add_filter(
    'tiny_mce_before_init',
    function($init_array){
      global $allowedposttags;
      $init_array['valid_elements']          = '*[*]';
      $init_array['extended_valid_elements'] = '*[*]';
      $init_array['valid_children']          = '+a[' . implode( '|', array_keys( $allowedposttags ) ) . ']';
      $init_array['indent']                  = true;
      $init_array['wpautop']                 = false;
      $init_array['force_p_newlines']        = false;
      return $init_array;
    }
  );

// ContactForm7で自動挿入されるPタグ、brタグを削除
add_filter('wpcf7_autop_or_not', 'wpcf7_autop_return_false');
function wpcf7_autop_return_false() {
  return false;
}

// 固定ページで「抜粋」を有効化
add_post_type_support('page', 'excerpt');

// カテゴリーとタグのmeta descriptionからpタグを除去
remove_filter('term_description','wpautop');

function custom_wpcf7_validate_name( $result, $tags ) {
    foreach ( $tags as $tag ) {
        $name = $tag['name'];
        $input = $_POST[ $name ];

        if ( $name == 'your-name' && $input == '' ) {
            $result->invalidate( $name, 'お名前を入力してください' );
        }
        if ( $name == 'your-kana' && $input == '' ) {
            $result->invalidate( $name, 'ふりがなを入力してください' );
        }
        if ( $name == 'your-tel' && $input == '' ) {
            $result->invalidate( $name, 'お電話番号を入力してください' );
        }
        if ( $name == 'your-mail' && $input == '' ) {
            $result->invalidate( $name, 'メールアドレスを入力してください' );
        }
        if ( $name == 'textarea' && $input == '' ) {
            $result->invalidate( $name, 'お問い合わせ内容を入力してください' );
        }
//        if ( $name == 'checkbox-708' && ( !isset($input) || empty($input) ) ) {
//     		$result->invalidate( $name, '選択してください' );
// 		}
        if ( $name == 'checkbox-001' && $input == '' ) {
            $result->invalidate( $name, '最低1つ選択してください' );
        }
    }
    return $result;
}
add_filter( 'wpcf7_validate', 'custom_wpcf7_validate_name', 11, 2 );

